package si.um.opj.glatki.logic;

public enum FoodItemType {
    FROZEN, FRESH;
}
